import React from "react";
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame, interpolate} from "remotion";
import {C} from "./theme";
import {LAYOUT} from "./config";
import {sf, sdur} from "./timeline";
import {Captions} from "./Captions";
import {S1, S2, S3} from "./scenes1";
import {S4, S5, S6} from "./scenes2";
import {S7, S8, S9, S10} from "./scenes3";

const SCENES = [S1, S2, S3, S4, S5, S6, S7, S8, S9, S10];

const Background: React.FC = () => {
  const f = useCurrentFrame();
  const {w, h} = LAYOUT;
  return (
    <AbsoluteFill>
      <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
        <rect width={w} height={h} fill={C.bg} />
        <circle cx={w * 0.2 + Math.sin(f / 90) * 40} cy={h * 0.18 + Math.cos(f / 110) * 30} r={w * 0.45} fill={C.bg2} opacity={0.55} />
        <circle cx={w * 0.85 + Math.cos(f / 100) * 40} cy={h * 0.62 + Math.sin(f / 85) * 30} r={w * 0.4} fill={C.bg2} opacity={0.4} />
      </svg>
    </AbsoluteFill>
  );
};

const Fade: React.FC<{dur: number; first?: boolean; last?: boolean; children: React.ReactNode}> = ({dur, first, last, children}) => {
  const f = useCurrentFrame();
  const a = first ? 1 : interpolate(f, [0, 8], [0, 1], {extrapolateRight: "clamp"});
  const b = interpolate(f, [dur - (last ? 24 : 8), dur], [1, 0], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return <g opacity={Math.min(a, b)}>{children}</g>;
};

export const Main: React.FC = () => {
  const {w, h, vx, vy, vs} = LAYOUT;
  return (
    <AbsoluteFill style={{backgroundColor: C.bg}}>
      <Background />
      <Audio src={staticFile("audio/voiceover.mp3")} />
      <AbsoluteFill>
        <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
          <g transform={`translate(${vx} ${vy}) scale(${vs})`}>
            {SCENES.map((Sc, i) => (
              <Sequence key={i} from={sf(i)} durationInFrames={sdur(i)} layout="none">
                <Fade dur={sdur(i)} first={i === 0} last={i === SCENES.length - 1}>
                  <Sc />
                </Fade>
              </Sequence>
            ))}
          </g>
        </svg>
      </AbsoluteFill>
      <Captions />
    </AbsoluteFill>
  );
};
