import {FPS, TOTAL_FRAMES} from "./config";

// সিনের শুরুর সময় (সেকেন্ড)
export const SCENE_START = [0, 2.5, 5.1, 9.0, 12.4, 14.9, 19.6, 22.5, 26.0, 29.2];
export const sf = (i: number) => Math.round(SCENE_START[i] * FPS);
export const sdur = (i: number) =>
  (i < SCENE_START.length - 1 ? sf(i + 1) + 6 : TOTAL_FRAMES) - sf(i);
// অডিওর সেকেন্ড → সিনের লোকাল ফ্রেম
export const cueF = (sec: number, i: number) => Math.round(sec * FPS) - sf(i);
