// রেশিও এক জায়গায়: শুধু RATIO বদলালেই লেআউট বদলাবে।
export type Ratio = "9:16" | "16:9";
export const RATIO: Ratio = "9:16";

export const FPS = 30;
export const AUDIO_SEC = 33.75;
export const TOTAL_FRAMES = Math.ceil(AUDIO_SEC * FPS);

// vx, vy = ভিজুয়াল এলাকার কেন্দ্র; vs = স্কেল; capY = ক্যাপশনের কেন্দ্র-Y
const LAYOUTS = {
  "9:16": {w: 1080, h: 1920, vx: 540, vy: 760, vs: 1, capY: 1430, capSize: 76, capW: 920, safeTop: 220, safeBottom: 380},
  "16:9": {w: 1920, h: 1080, vx: 960, vy: 430, vs: 0.82, capY: 900, capSize: 60, capW: 1500, safeTop: 80, safeBottom: 120},
};
export const LAYOUT = LAYOUTS[RATIO];
