import React from "react";
import {useCurrentFrame} from "remotion";
import {C} from "./theme";
import {keySpring, ease, lerp, bob} from "./anim";
import {cueF} from "./timeline";
import {Person, starPath, Stamp, Pulse} from "./icons";

// সিন ৪: "এই একটা বছরে কত কিছু বদলে গেল।" — বারোটি স্মৃতি-চিপে রঙের ঢেউ
export const S4: React.FC = () => {
  const f = useCurrentFrame();
  const c = (s: number) => cueF(s, 3);
  const reveal = ease(f, c(9.12), c(10.2) - c(9.12));
  const wave = ease(f, c(10.55), c(11.9) - c(10.55));
  const colors = [C.amber, C.mute, C.no, C.ink, C.line, C.amberSoft, C.mute, C.no, C.amber, C.ink, C.line, C.amberSoft];
  return (
    <g>
      <text x={0} y={-220} textAnchor="middle" fontSize={54} fontWeight={700} fill={C.ink}>এক বছরে বদলে যাওয়া</text>
      {Array.from({length: 12}).map((_, i) => {
        const col = i % 4, row = Math.floor(i / 4);
        const x = (col - 1.5) * 172;
        const y = -70 + row * 142;
        const p = keySpring(f, c(9.15) + i * 3);
        const shift = Math.sin((f - c(10.5) - i * 2) / 8) * 22 * wave;
        return (
          <g key={i} transform={`translate(${x} ${y + (1 - p) * 90 + shift}) scale(${p})`}>
            <rect x={-70} y={-48} width={140} height={96} rx={22} fill={C.card} stroke={colors[i]} strokeWidth={7} />
            <circle r={17 + 5 * wave} fill={colors[i]} opacity={0.9} />
            <path d={`M -30 25 Q 0 ${10 - 18 * wave} 30 25`} fill="none" stroke={C.ink} strokeWidth={5} strokeLinecap="round" opacity={0.8} />
          </g>
        );
      })}
      <Pulse f={f} at={c(11.65)} r0={80} r1={420} dur={34} color={C.amber} />
    </g>
  );
};

// সিন ৫: "কেউ কাছে এল, কেউ দূরে চলে গেল।" — কাছে আসা ও দূরে সরে যাওয়া মানুষ
export const S5: React.FC = () => {
  const f = useCurrentFrame();
  const c = (s: number) => cueF(s, 4);
  const a = keySpring(f, c(12.48));
  const b = keySpring(f, c(12.7));
  const move = ease(f, c(13.25), c(14.35) - c(13.25));
  const glow = 0.35 + 0.25 * (1 + Math.sin(f / 7));
  return (
    <g>
      <g transform={`translate(${lerp(-360, -145, a)} ${bob(f, 8, 72)}) scale(${a})`}>
        <Person color={C.mute} />
      </g>
      <g transform={`translate(${lerp(360, 145, b)} ${bob(f, 8, 72, 1)}) scale(${b})`}>
        <Person color={C.amber} />
      </g>
      <g transform={`translate(${lerp(0, 520, move)} 12) scale(${1 - 0.18 * move})`} opacity={1 - 0.35 * move}>
        <Person color={C.no} />
      </g>
      <path d="M -70 170 Q 0 215 70 170" fill="none" stroke={C.amber} strokeWidth={8} strokeLinecap="round" opacity={glow} />
      <circle cx={0} cy={-150} r={260} fill="none" stroke={C.line} strokeWidth={5} opacity={0.35} />
    </g>
  );
};

// সিন ৬: "কিছু স্বপ্ন পূরণ হলো, আবার কিছু স্বপ্ন অপূর্ণই রয়ে গেল।"
export const S6: React.FC = () => {
  const f = useCurrentFrame();
  const c = (s: number) => cueF(s, 5);
  const left = keySpring(f, c(15.0));
  const right = keySpring(f, c(16.7));
  const ok = ease(f, c(16.0), c(16.8) - c(16.0));
  const no = ease(f, c(18.0), c(18.8) - c(18.0));
  return (
    <g>
      <g transform={`translate(-190 -20) scale(${left})`}>
        <path d={starPath(118)} fill={C.amber} stroke={C.amberSoft} strokeWidth={7} />
        <g transform={`translate(0 185) scale(${ok})`}><Stamp kind="ok" /></g>
      </g>
      <g transform={`translate(190 -20) scale(${right})`}>
        <path d={starPath(118)} fill={C.card} stroke={C.mute} strokeWidth={8} />
        <path d="M -48 0 H 48" stroke={C.mute} strokeWidth={10} strokeLinecap="round" />
        <g transform={`translate(0 185) scale(${no})`}><Stamp kind="no" /></g>
      </g>
      <text x={-190} y={330} textAnchor="middle" fontSize={40} fontWeight={700} fill={C.amber}>পূরণ</text>
      <text x={190} y={330} textAnchor="middle" fontSize={40} fontWeight={700} fill={C.mute}>অপূর্ণ</text>
    </g>
  );
};
