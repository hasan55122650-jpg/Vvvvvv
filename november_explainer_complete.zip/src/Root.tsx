import React from "react";
import {Composition} from "remotion";
import {Main} from "./Main";
import {FPS, LAYOUT, TOTAL_FRAMES} from "./config";

export const Root: React.FC = () => (
  <Composition
    id="Explainer"
    component={Main}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={LAYOUT.w}
    height={LAYOUT.h}
  />
);
