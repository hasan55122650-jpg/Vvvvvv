import React from "react";
import {useCurrentFrame, interpolate} from "remotion";
import {ENTRIES} from "./captions";
import {C} from "./theme";
import {fontFamily} from "./fonts";
import {LAYOUT, FPS} from "./config";

type W = {w: string; s: number; e: number};
type Page = {words: W[]; s: number; e: number};

// SRT এন্ট্রির সময় শব্দের দৈর্ঘ্য অনুপাতে ভাগ করে শব্দ-সময় বানানো হয়
const buildPages = (): Page[] => {
  const words: W[] = [];
  for (const [s, e, t] of ENTRIES) {
    const ws = t.split(/\s+/).filter(Boolean);
    const total = ws.reduce((a, w) => a + w.length, 0) || 1;
    let cur = s;
    for (const w of ws) {
      const d = ((e - s) * w.length) / total;
      words.push({w, s: cur, e: cur + d});
      cur += d;
    }
  }
  const pages: Page[] = [];
  let acc: W[] = [];
  words.forEach((w, i) => {
    acc.push(w);
    const next = words[i + 1];
    const gap = next ? next.s - w.e : 99;
    const punct = /[।,.?!]$/.test(w.w);
    if ((punct && acc.length >= 2) || gap > 0.45 || acc.length >= 8 || !next) {
      pages.push({words: acc, s: acc[0].s, e: w.e});
      acc = [];
    }
  });
  return pages;
};
const PAGES = buildPages();

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const idx = PAGES.findIndex(
    (p, i) => t >= p.s - 0.05 && t < Math.min(p.e + 0.3, PAGES[i + 1] ? PAGES[i + 1].s - 0.02 : 99)
  );
  if (idx < 0) return null;
  const p = PAGES[idx];
  const enter = interpolate(t, [p.s - 0.05, p.s + 0.1], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return (
    <div
      style={{
        position: "absolute",
        left: (LAYOUT.w - LAYOUT.capW) / 2,
        top: LAYOUT.capY - 140,
        width: LAYOUT.capW,
        height: 280,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        opacity: enter,
        transform: `translateY(${(1 - enter) * 14}px)`,
      }}
    >
      <div style={{display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "0 22px", textAlign: "center"}}>
        {p.words.map((w, i) => {
          const cur = t >= w.s && t < w.e;
          const spoken = t >= w.e;
          const sc = cur ? interpolate(t, [w.s, w.s + 0.12], [1, 1.07], {extrapolateRight: "clamp"}) : 1;
          return (
            <span
              key={i}
              style={{
                display: "inline-block",
                fontFamily,
                fontWeight: 700,
                fontSize: LAYOUT.capSize,
                lineHeight: 1.5,
                color: cur ? C.amber : spoken ? C.ink : "rgba(244,241,234,0.45)",
                transform: `scale(${sc})`,
              }}
            >
              {w.w}
            </span>
          );
        })}
      </div>
    </div>
  );
};
