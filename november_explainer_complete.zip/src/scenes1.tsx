import React from "react";
import {useCurrentFrame} from "remotion";
import {C} from "./theme";
import {keySpring, ease, lerp, bob} from "./anim";
import {cueF} from "./timeline";
import {Calendar, Door, Clock, Pulse} from "./icons";

// সিন ১: "নভেম্বরটাও চলে যাচ্ছে।"
export const S1: React.FC = () => {
  const f = useCurrentFrame();
  const c = (s: number) => cueF(s, 0);
  const pop = keySpring(f, c(0.15));
  const out = ease(f, c(1.62), 22);
  const crossed = Math.floor(ease(f, c(0.85), c(1.55) - c(0.85)) * 10);
  const leaf = ease(f, c(1.2), 40);
  return (
    <g>
      <g transform={`translate(${lerp(0, -640, out)} ${bob(f, 10, 70) - 40}) rotate(${lerp(0, -20, out) + bob(f, 2, 80)}) scale(${pop * 1.3})`}>
        <Calendar label="নভেম্বর" crossed={crossed} />
      </g>
      <g transform="translate(0 -40)">
        <Pulse f={f} at={c(0.78)} r0={200} r1={320} dur={26} />
      </g>
      <g
        transform={`translate(${lerp(40, 300, leaf)} ${lerp(-120, 380, leaf)}) rotate(${lerp(0, 140, leaf)})`}
        opacity={leaf > 0 ? 1 - leaf * 0.9 : 0}
      >
        <rect x={-45} y={-55} width={90} height={110} rx={12} fill={C.amber} />
      </g>
    </g>
  );
};

// সিন ২: "দেখতে দেখতে Decemberটা দরজায় এসে দাঁড়িয়েছে।"
export const S2: React.FC = () => {
  const f = useCurrentFrame();
  const c = (s: number) => cueF(s, 1);
  const dp = keySpring(f, c(2.72));
  const inx = ease(f, c(3.96), c(4.55) - c(3.96));
  const cp = keySpring(f, c(3.96));
  return (
    <g>
      <g transform={`translate(-150 ${20 + bob(f, 6, 80)}) scale(${dp * 1.15})`}>
        <Door />
      </g>
      <g transform={`translate(${lerp(640, 170, inx)} ${60 + bob(f, 8, 66, 1)}) rotate(${lerp(14, -4, inx)}) scale(${0.95 * Math.min(1, cp * 1.2)})`}>
        <Calendar label="ডিসেম্বর" />
      </g>
      <g transform="translate(-51 89)">
        <Pulse f={f} at={c(4.5)} r0={20} r1={120} dur={26} />
        <Pulse f={f} at={c(4.5) + 8} r0={20} r1={120} dur={26} />
        <Pulse f={f} at={c(4.5) + 16} r0={20} r1={120} dur={26} />
      </g>
    </g>
  );
};

// সিন ৩: "আর কিছুদিন পরেই শেষ হয়ে যাবে এই বছরটা।"
export const S3: React.FC = () => {
  const f = useCurrentFrame();
  const c = (s: number) => cueF(s, 2);
  const rp = keySpring(f, c(5.12));
  const lit = Math.min(11, Math.floor(ease(f, c(5.15), c(6.1) - c(5.15)) * 11.99));
  const last = ease(f, c(7.5), c(8.5) - c(7.5));
  const full = f >= c(8.5);
  const ticks = Array.from({length: 12}).map((_, i) => {
    const a = (i * 30 * Math.PI) / 180;
    const on = i < lit || (i === 11 && full);
    let op = 1;
    let col = on ? C.amber : C.line;
    if (i === 11 && !full && f >= c(6.18)) {
      col = C.amber;
      op = 0.35 + 0.35 * (1 + Math.sin(f / 4)) * (1 + last);
    }
    return (
      <line key={i} x1={Math.sin(a) * 215} y1={-Math.cos(a) * 215} x2={Math.sin(a) * 295} y2={-Math.cos(a) * 295}
        stroke={col} opacity={Math.min(1, op)} strokeWidth={26} strokeLinecap="round" />
    );
  });
  return (
    <g transform={`translate(0 -20) scale(${rp})`}>
      <g transform={`scale(${full ? 1 + 0.04 * Math.sin(Math.min(1, (f - c(8.5)) / 12) * Math.PI) : 1})`}>
        {ticks}
        <g transform="scale(1.3)">
          <Clock angle={f * 8} />
        </g>
      </g>
      <Pulse f={f} at={c(8.5)} r0={300} r1={430} dur={30} />
    </g>
  );
};
