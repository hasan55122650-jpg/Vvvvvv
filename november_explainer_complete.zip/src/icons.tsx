import React from "react";
import {C} from "./theme";
import {fontFamily} from "./fonts";

export const Calendar: React.FC<{label: string; crossed?: number}> = ({label, crossed = 0}) => {
  const cells: React.ReactNode[] = [];
  for (let r = 0; r < 4; r++) {
    for (let k = 0; k < 5; k++) {
      const i = r * 5 + k;
      const x = -96 + k * 48;
      const y = -20 + r * 46;
      cells.push(
        <g key={i}>
          <rect x={x - 16} y={y - 16} width={32} height={32} rx={8} fill={C.bg2} />
          {i < crossed && (
            <g stroke={C.no} strokeWidth={6} strokeLinecap="round">
              <line x1={x - 10} y1={y - 10} x2={x + 10} y2={y + 10} />
              <line x1={x + 10} y1={y - 10} x2={x - 10} y2={y + 10} />
            </g>
          )}
        </g>
      );
    }
  }
  return (
    <g>
      <rect x={-140} y={-150} width={280} height={320} rx={30} fill={C.card} stroke={C.line} strokeWidth={6} />
      <path d="M -140 -120 A 30 30 0 0 1 -110 -150 H 110 A 30 30 0 0 1 140 -120 V -60 H -140 Z" fill={C.amber} />
      <rect x={-84} y={-178} width={22} height={50} rx={11} fill={C.ink} />
      <rect x={62} y={-178} width={22} height={50} rx={11} fill={C.ink} />
      <text x={0} y={-82} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={44} fill={C.bg}>
        {label}
      </text>
      {cells}
    </g>
  );
};

export const Door: React.FC = () => (
  <g>
    <path d="M -130 210 V -90 A 130 130 0 0 1 130 -90 V 210 Z" fill={C.card} stroke={C.line} strokeWidth={8} />
    <path d="M -85 170 V -80 A 85 85 0 0 1 85 -80 V 170 Z" fill="none" stroke={C.line} strokeWidth={5} />
    <circle cx={86} cy={60} r={14} fill={C.amber} />
    <rect x={-170} y={210} width={340} height={14} rx={7} fill={C.line} />
  </g>
);

export const Person: React.FC<{color?: string}> = ({color = C.mute}) => (
  <g>
    <circle cx={0} cy={-92} r={46} fill={color} />
    <path d="M -64 80 V 10 A 64 64 0 0 1 64 10 V 80 Z" fill={color} />
  </g>
);

export const starPath = (r: number) => {
  const p: string[] = [];
  for (let i = 0; i < 10; i++) {
    const a = ((-90 + i * 36) * Math.PI) / 180;
    const rr = i % 2 === 0 ? r : r * 0.45;
    p.push(`${(Math.cos(a) * rr).toFixed(1)},${(Math.sin(a) * rr).toFixed(1)}`);
  }
  return "M " + p.join(" L ") + " Z";
};

export const Stamp: React.FC<{kind: "ok" | "no"}> = ({kind}) => {
  const col = kind === "ok" ? C.amber : C.no;
  return (
    <g>
      <circle r={62} fill={C.bg} stroke={col} strokeWidth={10} />
      {kind === "ok" ? (
        <polyline points="-30,2 -8,26 32,-24" fill="none" stroke={col} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" />
      ) : (
        <g stroke={col} strokeWidth={14} strokeLinecap="round">
          <line x1={-26} y1={-26} x2={26} y2={26} />
          <line x1={26} y1={-26} x2={-26} y2={26} />
        </g>
      )}
    </g>
  );
};

export const Pulse: React.FC<{f: number; at: number; dur?: number; r0?: number; r1?: number; color?: string; w?: number}> = ({
  f, at, dur = 30, r0 = 40, r1 = 200, color = C.amber, w = 8,
}) => {
  const t = (f - at) / dur;
  if (t < 0 || t >= 1) return null;
  return <circle r={r0 + (r1 - r0) * t} fill="none" stroke={color} strokeWidth={w * (1 - t) + 1} opacity={1 - t} />;
};

export const Clock: React.FC<{angle: number}> = ({angle}) => (
  <g>
    <circle r={130} fill={C.card} stroke={C.line} strokeWidth={8} />
    {Array.from({length: 12}).map((_, i) => {
      const a = (i * 30 * Math.PI) / 180;
      return (
        <line key={i} x1={Math.sin(a) * 100} y1={-Math.cos(a) * 100} x2={Math.sin(a) * 116} y2={-Math.cos(a) * 116}
          stroke={C.mute} strokeWidth={6} strokeLinecap="round" />
      );
    })}
    <g transform={`rotate(${angle / 12})`}>
      <line x1={0} y1={8} x2={0} y2={-60} stroke={C.ink} strokeWidth={12} strokeLinecap="round" />
    </g>
    <g transform={`rotate(${angle})`}>
      <line x1={0} y1={14} x2={0} y2={-92} stroke={C.amber} strokeWidth={10} strokeLinecap="round" />
    </g>
    <circle r={12} fill={C.ink} />
  </g>
);

export const Pause: React.FC = () => (
  <g>
    <rect x={-52} y={-60} width={34} height={120} rx={10} fill={C.ink} />
    <rect x={18} y={-60} width={34} height={120} rx={10} fill={C.ink} />
  </g>
);

const pageR = "M 0 -100 Q 100 -130 200 -100 V 110 Q 100 80 0 110 Z";
const pageL = "M 0 -100 Q -100 -130 -200 -100 V 110 Q -100 80 0 110 Z";

// flip: 0..1 — ডান পাতা উল্টে বাঁয়ে যায়
export const Book: React.FC<{flip?: number}> = ({flip = 0}) => (
  <g>
    <rect x={-216} y={-114} width={432} height={246} rx={22} fill={C.amber} />
    <path d={pageL} fill={C.ink} />
    <path d={pageR} fill={C.ink} />
    {[-40, 0, 40, 80].map((y) => (
      <g key={y} stroke={C.mute} strokeWidth={6} strokeLinecap="round" opacity={0.7}>
        <line x1={-160} y1={y - 20} x2={-40} y2={y - 10} />
        <line x1={160} y1={y - 20} x2={40} y2={y - 10} />
      </g>
    ))}
    <g transform={`scale(${1 - 2 * flip} 1)`}>
      <path d={pageR} fill="#E6E1D6" stroke={C.line} strokeWidth={3} />
      <line x1={40} y1={-30} x2={160} y2={-30} stroke={C.mute} strokeWidth={6} strokeLinecap="round" opacity={0.7} />
      <line x1={40} y1={10} x2={160} y2={10} stroke={C.mute} strokeWidth={6} strokeLinecap="round" opacity={0.7} />
    </g>
    <line x1={0} y1={-100} x2={0} y2={110} stroke={C.line} strokeWidth={5} />
  </g>
);
