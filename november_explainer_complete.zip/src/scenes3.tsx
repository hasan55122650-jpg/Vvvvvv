import React from "react";
import {useCurrentFrame} from "remotion";
import {C} from "./theme";
import {keySpring, ease, lerp, bob} from "./anim";
import {cueF} from "./timeline";
import {Calendar, Book, Stamp, Pulse} from "./icons";

// সিন ৭: "তবুও জীবন কিন্তু থেমে থাকেনি।" — চলমান পালস লাইন
export const S7: React.FC = () => {
  const f = useCurrentFrame();
  const c = (s: number) => cueF(s, 6);
  const draw = ease(f, c(19.72), c(21.0) - c(19.72));
  const stop = ease(f, c(21.55), c(22.15) - c(21.55));
  const x = lerp(-430, 430, draw);
  return (
    <g>
      <path d="M -440 0 H -260 L -210 -65 L -150 90 L -75 -120 L 0 70 L 70 -35 L 125 0 H 440" fill="none" stroke={C.line} strokeWidth={13} strokeLinecap="round" strokeLinejoin="round" opacity={0.5} />
      <path d={`M -440 0 H ${x}`} fill="none" stroke={C.amber} strokeWidth={16} strokeLinecap="round" />
      <circle cx={x} cy={0} r={22} fill={C.ink} stroke={C.amber} strokeWidth={9} />
      <g transform={`translate(0 230) scale(${keySpring(f, c(20.0))})`} opacity={1 - stop}>
        <Pulse f={f} at={c(20.0)} r0={25} r1={170} dur={38} />
      </g>
      <g transform={`translate(0 0) scale(${stop})`}>
        <circle r={105} fill={C.bg} stroke={C.no} strokeWidth={12} />
        <path d="M -42 -42 L 42 42 M 42 -42 L -42 42" stroke={C.no} strokeWidth={18} strokeLinecap="round" />
      </g>
    </g>
  );
};

// সিন ৮: "নতুন বছর আসবে, নতুন গল্প শুরু হবে।" — নতুন ক্যালেন্ডার ও বই
export const S8: React.FC = () => {
  const f = useCurrentFrame();
  const c = (s: number) => cueF(s, 7);
  const cal = keySpring(f, c(22.58));
  const book = keySpring(f, c(23.65));
  const open = ease(f, c(24.35), c(25.2) - c(24.35));
  return (
    <g>
      <g transform={`translate(-190 ${-35 + bob(f, 7, 80)}) rotate(${lerp(-12, 0, cal)}) scale(${cal})`}>
        <Calendar label="জানুয়ারি" />
      </g>
      <g transform={`translate(210 85) scale(${book}) rotate(${lerp(12, 0, open)})`}>
        <Book flip={0.08 * Math.sin(f / 8) * open} />
      </g>
      <Pulse f={f} at={c(25.0)} r0={50} r1={300} dur={34} />
    </g>
  );
};

// সিন ৯: "শুধু মনে রেখো, বছর শেষ হবে, গল্প নয়।" — ক্যালেন্ডার শেষ, বই চলবে
export const S9: React.FC = () => {
  const f = useCurrentFrame();
  const c = (s: number) => cueF(s, 8);
  const p = keySpring(f, c(26.08));
  const cross = ease(f, c(27.15), c(28.0) - c(27.15));
  const book = keySpring(f, c(27.4));
  return (
    <g>
      <g transform={`translate(-205 -10) scale(${p})`}>
        <Calendar label="বছর" />
        <g opacity={cross}>
          <path d="M -125 -130 L 125 145 M 125 -130 L -125 145" stroke={C.no} strokeWidth={20} strokeLinecap="round" />
        </g>
      </g>
      <g transform={`translate(205 35) scale(${book})`}>
        <Book flip={0.12 * Math.sin(f / 10)} />
        <g transform="translate(150 -140) scale(0.72)"><Stamp kind="ok" /></g>
      </g>
      <text x={0} y={365} textAnchor="middle" fontSize={54} fontWeight={700} fill={C.amber} opacity={ease(f, c(28.0), 20)}>গল্প চলতেই থাকবে</text>
    </g>
  );
};

// সিন ১০: শেষ অংশ — বইয়ের পাতা উল্টে নতুন গল্পে ফেড
export const S10: React.FC = () => {
  const f = useCurrentFrame();
  const c = (s: number) => cueF(s, 9);
  const enter = keySpring(f, c(29.25));
  const flip = ease(f, c(30.0), c(32.25) - c(30.0));
  const fade = ease(f, c(32.75), c(33.7) - c(32.75));
  return (
    <g opacity={1 - fade}>
      <g transform={`translate(0 ${lerp(100, -20, enter) + bob(f, 5, 100)}) scale(${enter * (1 + 0.025 * Math.sin(f / 12))})`}>
        <Book flip={flip} />
      </g>
      <text x={0} y={-260} textAnchor="middle" fontSize={66} fontWeight={700} fill={C.amber}>বছর শেষ হবে</text>
      <text x={0} y={-185} textAnchor="middle" fontSize={58} fontWeight={700} fill={C.ink}>গল্প নয়</text>
      <Pulse f={f} at={c(32.1)} r0={80} r1={460} dur={50} color={C.amber} />
    </g>
  );
};
