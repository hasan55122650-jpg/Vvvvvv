import {spring, interpolate, Easing} from "remotion";
import {FPS} from "./config";

// মেজাজ: শান্ত ও মসৃণ — ওভারশুট কম
export const keySpring = (f: number, at: number) =>
  f < at ? 0 : spring({frame: f - at, fps: FPS, config: {damping: 16, stiffness: 110, mass: 0.9}});

export const softSpring = (f: number, at: number) =>
  f < at ? 0 : spring({frame: f - at, fps: FPS, config: {damping: 200, stiffness: 80}});

export const ease = (f: number, at: number, dur: number) =>
  interpolate(f, [at, at + Math.max(1, dur)], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.inOut(Easing.cubic),
  });

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

// ছবি যেন কখনো স্থির না থাকে: ধীর দোলা
export const bob = (f: number, amp = 8, period = 60, phase = 0) =>
  Math.sin((f / period) * Math.PI * 2 + phase) * amp;
