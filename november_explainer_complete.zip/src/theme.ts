export const C = {
  bg: "#14213D",
  bg2: "#1B2D55",
  card: "#22365F",
  line: "#3A5287",
  ink: "#F4F1EA",
  mute: "#8FA3CC",
  amber: "#FCA311",
  amberSoft: "#FFD38A",
  no: "#FF8A80",
};
